package Result;

public class ErrorResultUnused {
    public String message;
    public boolean success = false;

    public ErrorResultUnused(String message)
    {
        this.message = message;
    }
}
